<!DOCTYPE html>
<html>
<head>
 <title>S A G</title>
</head>
<body>

 <h1>WELCOME TO OUR WEBSITE </h1>
 <h3> YOUR NEW PASSWORD IS : {{$data['body']}}</h3>
</body>
</html>
