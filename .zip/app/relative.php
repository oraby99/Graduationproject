<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class relative extends Model
{
    protected $fillable = [
        'name',
    ];
}
